# 3. Diagrama de Casos de Uso

## Atores
-   **Usuário**: Pessoa proprietária da residência ou comércio que utiliza o sistema para monitorar seu consumo de energia.

## Diagrama

O diagrama abaixo ilustra as principais interações do ator `Usuário` com o sistema EcoWatt Monitor.

![Diagrama de Casos de Uso do EcoWatt Monitor](img/diagram.png)